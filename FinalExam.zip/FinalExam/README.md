# 🏭 ZONA ACME 🏭

## Tabla de Contenido 📋
| Indice | Título  |
|--|--|
| 1. | [Descripción](#descripción-) |
| 3. | [Funcionalidades](#funcionalidades-) |
| 4. | [Tecnologías](#tecnologías-%EF%B8%8F) |
| 5. | [USO](#uso-) |
| 6. | [Contribución](#contribución-) |
| 7. | [Contacto](#contacto-) |

## Descripción 💻

El propósito de este proyecto es desarrollar un sistema en Java para una institución financiera que permita gestionar cuentas corrientes y emitir cheques de manera eficiente. Este sistema debe incluir operaciones administrativas y financieras clave, aplicando los principios más avanzados de programación orientada a objetos, patrones de diseño, y acceso a bases de datos.


## Funcionalidades 🌐

El sistema cubre las siguientes funcionalidades clave:

*1. Operaciones CRUD: *
*Cheques:*

-   Emitir nuevos cheques para un cliente verificando los límites y el saldo disponible.

-   Listar los cheques emitidos previamente de un cliente
2. **Validaciones:**

    -   Antes de cualquier operación, verificar que el cliente esté activo y tenga cuentas válidas.
    -   Comprobar que el saldo de la cuenta cubra el monto del cheque antes de emitirlo.

3. **Reportes:**

    -   Generar un listado de cheques emitidos, mostrando:

        -   Cliente emisor.
        -   Beneficiario.
        -   Monto.
        -   Prioridad.

    -   Guardar los reportes en archivos de texto con un formato claro y ordenado. El formato es yyyymmdd-hhmmss-procesamiento-cheques.txt

4. **Procesamiento de Cheques Pendientes:**

   El sistema debe procesar cheques pendientes de manera eficiente, priorizando aquellos marcados como de alta urgencia. Durante este proceso, el usuario podrá continuar realizando otras operaciones en el sistema sin interrupciones. Los cheques serán ordenados según su prioridad y luego procesados uno por uno, validando información clave como el saldo disponible en la cuenta asociada y la autenticidad de los datos del cheque. Una vez completado el procesamiento, los resultados deben guardarse en un archivo de texto, detallando información como el ID del cheque, el estado final (procesado o rechazado), y las razones en caso de rechazo.

   Los archivos de procesamiento deben llevar el formato yyyymmdd-hhmmss-procesamiento-cheques.txt. La hora está en formato militar.

   Con el fin de colapsar el sistema, este listsado se empezará a generar 10 segundos después de lanzarlo y el usuario podrá seguir con su trabajo en el sistema

   Un cheque se considera _pendiente_ si cumple con las siguientes condiciones:

    -   _**Estado no finalizado:**_ El cheque no ha sido marcado como "procesado" o "rechazado".
    -   **_Sin cobro asociado:_** No hay evidencia de que el monto haya sido debitado de la cuenta emisora.



*5. Manejo de Incidentes:*
- Los supervisores de seguridad pueden registrar anotaciones sobre comportamientos indebidos.
- Estas anotaciones pueden aplicar la opción del estado de prohibición de acceso al complejo.
- El levantamiento de esta restricción debe estar acompañado de una justificación y quedar registrado.
- Las anotaciones y restricciones nunca se borran del sistema, siempre queda la trazabilidad de estas, aunque los estados cambien con el tiempo.

*6. Trazabilidad y Reportes:*
- Reportes detallados sobre usuarios activos e inactivos: supervisores, guardas y funcionarios.
- Listados de trabajadores e invitados por empresa.
- Informes de trazabilidad de acceso (ingresos y salidas) de trabajadores y funcionarios en rangos de fechas.



## Tecnologías 🖥️

- **Java:** Lenguaje de programación multiplataforma orientado a objetos que se ejecuta en miles de millones de dispositivos de todo el mundo.

  
- **MySQL Workbench:** Proporciona modelado de datos, desarrollo de SQL y herramientas de administración integrales para configuración de servidores, administración de usuarios, copias de seguridad y mucho más.
  
- **Visual Studio Code:** Editor de código fuente desarrollado por Microsoft para Windows, Linux, macOS y Web. Incluye soporte para la depuración, control integrado de Git, resaltado de sintaxis, finalización inteligente de código, fragmentos y refactorización de código.


> [!IMPORTANT]
> ## USO 🔧

Sigue los pasos a continuación para descargar, compilar y ejecutar los archivos Java de este proyecto.

- **Requisitos previos**

*Java Development Kit (JDK):*
- Asegúrate de tener instalado el JDK en tu computadora.
- Verifica la instalación ejecutando:
`(java -version)`

*Git:*
- Debes tener instalado Git para clonar el repositorio.
- Verifica la instalación ejecutando:
`(git --version)`

*Editor o IDE (opcional)*
- Puedes usar un editor de texto como VS Code o un IDE como IntelliJ IDEA, Eclipse o NetBeans para trabajar con los archivos Java.

----------------------------------------------

- **Pasos para clonar y ejecutar el proyecto**

*1. Clonar el repositorio*
- Abre una terminal o consola y ejecuta el siguiente comando:
`(git clone https://github.com/usuario/nombre-repositorio.git)`
- Reemplaza usuario y nombre-repositorio con el nombre del usuario y repositorio correspondiente.
- Ingresa al directorio del proyecto:
`(cd nombre-repositorio)`

*2. Compilar los archivos Java*
- Si los archivos están organizados en una estructura básica, puedes compilarlos usando javac. Por ejemplo:
`(javac src/*.java)`
- Si el proyecto incluye paquetes (carpetas organizadas por namespace), utiliza:
`(javac -d bin src/**/*.java)`

*3. Ejecutar la aplicación*
- Ejecuta la clase principal (la que contiene el método ***public static void main(String[] args***))
`(java -cp bin NombreDeLaClasePrincipal)`
- Asegúrate de reemplazar ***NombreDeLaClasePrincipal*** con el nombre exacto de la clase principal, y utiliza el nombre del paquete si aplica. Por ejemplo:
`(java -cp bin com.ejemplo.miapp.App)`

*Ejecutar con un IDE (opcional)*
Si prefieres usar un IDE, sigue estos pasos:

1. Abre el IDE de tu elección.
2. Importa el proyecto como un proyecto existente o selecciona "Abrir proyecto desde archivo/carpetas".
3. Configura el JDK si es necesario.
4. Encuentra la clase principal y ejecuta el programa.

> [!TIP]
> ## Contribución 👥

¡Me encantaría recibir tus contribuciones! Si deseas contribuir a este proyecto, por favor sigue estos pasos:

- Haz un fork del proyecto.
- Crea una nueva rama `(git checkout -b feature/nueva-funcionalidad)`.
- Realiza tus cambios y haz commit `(git commit -am 'Añadir nueva funcionalidad')`.
- Empuja la rama `(git push origin feature/nueva-funcionalidad)`.
- Abre un Pull Request.

> [!NOTE]
> ## Contacto 🧑‍💻

Hecho por [Gean Franco Jacome](https://github.com/gfranco7)  

Gean Franco Jácome Laguna -- (deepagmf710@gmail.com) 
