package Main.DAO.Cheques;


import Main.Modules.CRUD_DB;
import Main.ConexionDB.Conexion;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



// REQ: PATRONES DE DISEÑO
public class ChequesDAO {

    public static boolean insertCheque(String numero_cheque, int id_cuenta, String beneficiario, double monto,
                                       String monto_letras, String prioridad, String firma_digital, String estado,
                                       String razon_rechazo, String fecha_emision, String fecha_proceso, int cobrado, double cuenta_saldo_momento,
                                       String fecha_modificacion, String usuario_mpodificacion) {
        String query = "INSERT INTO Ninja(numero_cheque, id_cuenta, beneficiario, monto, monto_letras, prioridad," +
                " firma_digital, estado, razon_rechazo, fecha_emision, fecha_proceso, cobrado, cuenta_saldo_momento, fecha_modificacion," +
                " usuario_mpodificacion ) VALUES(?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?,?,?,?)";
        Cheques cheque = new Cheques (numero_cheque,id_cuenta, beneficiario, monto, monto_letras, prioridad, firma_digital,
                estado, razon_rechazo, fecha_emision, fecha_proceso, cobrado, cuenta_saldo_momento, fecha_modificacion, usuario_mpodificacion);

        try {
            CRUD_DB.setConnection(Conexion.getConexion());
            if (CRUD_DB.setAutoCommitDB(false)) {
                boolean result = CRUD_DB.insertIntoDB(query, cheque.getNumero_cheque(), cheque.getId_cuenta(),
                        cheque.getBeneficiario(), cheque.getMonto(), cheque.getMonto_letras(), cheque.getPrioridad(),
                        cheque.getFirma_digital(), cheque.getEstado(), cheque.getRazon_rechazo(), cheque.getFecha_emision(), cheque.getFehca_proceso(),
                        cheque.getCobrado(), cheque.getCuenta_saldo_momento(), cheque.getFecha_modificacion(), cheque.getUsuario_modificacion());
                if (result) {
                    CRUD_DB.commitDB();
                } else {
                    CRUD_DB.rollbackDB();
                }
                return result;
            }
        } catch (SQLException e) {
            System.out.println("Error en la operación de inserción: " + e.getMessage());
            CRUD_DB.rollbackDB();
        } finally {
            CRUD_DB.closeConnection();
        }

        return false;
    }


    public static boolean updateCheque(String numero_cheque, int id_cuenta, String beneficiario, double monto,
                                       String monto_letras, String prioridad, String firma_digital, String estado,
                                       String razon_rechazo, String fecha_emision, String fecha_proceso, int cobrado, double cuenta_saldo_momento,
                                       String fecha_modificacion, String usuario_mpodificacion) throws SQLException {
        String query = "UPDATE cheques SET numero_cheque = ?, id_cuenta = ?, beneficiario =?, monto=?, monto_letras=?, prioridad=?," +
                " firma_digital =?, estado=?, razon_rechazo=?, fecha_emision=?, fecha_proceso=?, cobrado=?, cuenta_saldo_momento=?, fecha_modificacion=?," +
                " usuario_mpodificacion=?";
        Cheques cheque = new Cheques (numero_cheque,id_cuenta, beneficiario, monto, monto_letras, prioridad, firma_digital,
                estado, razon_rechazo, fecha_emision, fecha_proceso, cobrado, cuenta_saldo_momento, fecha_modificacion, usuario_mpodificacion);

        try {
            CRUD_DB.setConnection(Conexion.getConexion());
            if (CRUD_DB.setAutoCommitDB(false)) {
                boolean result = CRUD_DB.insertIntoDB(query, cheque.getNumero_cheque(), cheque.getId_cuenta(),
                        cheque.getBeneficiario(), cheque.getMonto(), cheque.getMonto_letras(), cheque.getPrioridad(),
                        cheque.getFirma_digital(), cheque.getEstado(), cheque.getRazon_rechazo(), cheque.getFehca_proceso(),
                        cheque.getCobrado(), cheque.getCuenta_saldo_momento(), cheque.getFecha_modificacion(), cheque.getUsuario_modificacion());
                if (result) {
                    CRUD_DB.commitDB();
                } else {
                    CRUD_DB.rollbackDB();
                }
                return result;
            }
        } catch (SQLException e) {
            System.out.println("Error en la operación de inserción: " + e.getMessage());
            CRUD_DB.rollbackDB();
        } finally {
            CRUD_DB.closeConnection();
        }

        return false;
    }


    public static List<Cheques> getAllCheques() throws SQLException {
        String query = "SELECT * FROM cheques";
        List<Cheques> ListaCheques = new ArrayList<>();

        try {
            CRUD_DB.setConnection(Conexion.getConexion());
            ResultSet rs = CRUD_DB.queryDB(query);

            while (rs.next()) {
                Cheques cheques = new Cheques(
                        rs.getString("numero_cheque"),
                        rs.getInt("id_cuenta"),
                        rs.getString("beneficiario"),
                        rs.getInt("monto"),
                        rs.getString("monto_letras"),
                        rs.getString("prioridad"),
                        rs.getString("firma_digital"),
                        rs.getString("estado"),
                        rs.getString("razon_rechazo"),
                        rs.getString("fecha_emision"),
                        rs.getString("fecha_proceso"),
                        rs.getInt("cobrado"),
                        rs.getDouble("cuenta_saldo_momento"),
                        rs.getString("fecha_modificacion"),
                        rs.getString("usuario_modificacion")

                        );
                ListaCheques.add(cheques);
            }
            rs.close();
        } catch (SQLException e) {
            System.out.println("Error al obtener los cheques: " + e.getMessage());
            CRUD_DB.rollbackDB();
            throw e;
        } finally {
            CRUD_DB.closeConnection();
        }

        return ListaCheques;
    }


    public static Cheques getChequesById(int idCheque) throws SQLException {
        String query = "SELECT * FROM cheques WHERE id = ?";
        Cheques cheque = null;

        try {
            CRUD_DB.setConnection(Conexion.getConexion());
            ResultSet rs = CRUD_DB.queryDB(query, idCheque);

            while (rs.next()) {
                cheque = new Cheques(
                        rs.getString("numero_cheque"),
                        rs.getInt("id_cuenta"),
                        rs.getString("beneficiario"),
                        rs.getInt("monto"),
                        rs.getString("monto_letras"),
                        rs.getString("prioridad"),
                        rs.getString("firma_digital"),
                        rs.getString("estado"),
                        rs.getString("razon_rechazo"),
                        rs.getString("fecha_emision"),
                        rs.getString("fecha_proceso"),
                        rs.getInt("cobrado"),
                        rs.getDouble("cuenta_saldo_momento"),
                        rs.getString("fecha_modificacion"),
                        rs.getString("usuario_modificacion")

                );
            }
            rs.close();
        } catch (SQLException e) {
            System.out.println("Error al obtener los cheques: " + e.getMessage());
            CRUD_DB.rollbackDB();
            throw e;
        } finally {
            CRUD_DB.closeConnection();
        }

        return cheque;

    }


    public static boolean updateCheque(Cheques vet) {
        return false;
    }
}
