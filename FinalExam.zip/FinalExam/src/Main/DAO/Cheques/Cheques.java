package Main.DAO.Cheques;

import java.util.ArrayList;

public class Cheques {
    private int id;
    private String numero_cheque;
    private int id_cuenta;
    private String beneficiario;
    private double monto;
    private String monto_letras;
    private String prioridad;
    private String firma_digital;
    private String estado;
    private String razon_rechazo;

    private String fecha_emision;
    private String fecha_proceso;
    private int cobrado;
    private double cuenta_saldo_momento;
    private String fecha_modificacion;

    private String usuario_modificacion;

    private ArrayList <Cheques> ListaCheques;



    public Cheques(String numero_cheque, int id_cuenta, String beneficiario, double monto, String monto_letras,
                   String prioridad, String firma_digital, String estado, String razon_rechazo, String fecha_emision, String fecha_proceso,
                   int cobrado, double cuenta_saldo_momento, String fecha_modificacion, String usuario_modificacion) {
        this.numero_cheque = numero_cheque;
        this.id_cuenta = id_cuenta;
        this.beneficiario = beneficiario;
        this.monto = monto;
        this.monto_letras = monto_letras;
        this.prioridad = prioridad;
        this.firma_digital = firma_digital;
        this.estado = estado;
        this.razon_rechazo = razon_rechazo;
        this.fecha_emision = fecha_emision;
        this.fecha_proceso = fecha_proceso;
        this.cobrado = cobrado;
        this.cuenta_saldo_momento = cuenta_saldo_momento;
        this.fecha_modificacion = fecha_modificacion;
        this.usuario_modificacion = usuario_modificacion;

    }

    public String getFecha_emision() {
        return fecha_emision;
    }

    public void setFecha_emision(String fecha_emision) {
        this.fecha_emision = fecha_emision;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNumero_cheque() {
        return numero_cheque;
    }

    public void setNumero_cheque(String numero_cheque) {
        this.numero_cheque = numero_cheque;
    }

    public int getId_cuenta() {
        return id_cuenta;
    }

    public void setId_cuenta(int id_cuenta) {
        this.id_cuenta = id_cuenta;
    }

    public String getBeneficiario() {
        return beneficiario;
    }

    public void setBeneficiario(String beneficiario) {
        this.beneficiario = beneficiario;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public String getMonto_letras() {
        return monto_letras;
    }

    public void setMonto_letras(String monto_letras) {
        this.monto_letras = monto_letras;
    }

    public String getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(String prioridad) {
        this.prioridad = prioridad;
    }

    public String getFirma_digital() {
        return firma_digital;
    }

    public void setFirma_digital(String firma_digital) {
        this.firma_digital = firma_digital;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getRazon_rechazo() {
        return razon_rechazo;
    }

    public void setRazon_rechazo(String razon_rechazo) {
        this.razon_rechazo = razon_rechazo;
    }

    public String getFehca_proceso() {
        return fecha_proceso;
    }

    public void setFehca_proceso(String fehca_proceso) {
        this.fecha_proceso = fehca_proceso;
    }

    public int getCobrado() {
        return cobrado;
    }

    public void setCobrado(int cobrado) {
        this.cobrado = cobrado;
    }

    public double getCuenta_saldo_momento() {
        return cuenta_saldo_momento;
    }

    public void setCuenta_saldo_momento(double cuenta_saldo_momento) {
        this.cuenta_saldo_momento = cuenta_saldo_momento;
    }

    public String getFecha_modificacion() {
        return fecha_modificacion;
    }

    public void setFecha_modificacion(String fecha_modificacion) {
        this.fecha_modificacion = fecha_modificacion;
    }

    public String getUsuario_modificacion() {
        return usuario_modificacion;
    }

    public void setUsuario_modificacion(String usuario_modificacion) {
        this.usuario_modificacion = usuario_modificacion;
    }

    public ArrayList<Cheques> getListaCheques() {
        return ListaCheques;
    }

    public void setListaCheques(ArrayList<Cheques> listaCheques) {
        ListaCheques = listaCheques;
    }

    @Override
    public String toString() {
        return "Cheques: {" + "id=" + id + ", numero cheque = "+ numero_cheque + ", beneficiario =" + beneficiario +
                ", monto =" + monto + ", monto letras =" + monto_letras + ", prioridad=" + prioridad + ", firma_digital = "
                +firma_digital+ ", estado = "+estado +", razon_rechazo = "+razon_rechazo+ ", fehca_proceso = "+fecha_proceso+
                ", cobrado = "+cobrado +", cuenta_saldo_momento = "+cuenta_saldo_momento+ ", fecha_modificacion = "+
                fecha_modificacion+", usuario_modificacion = "+usuario_modificacion+'}';
    }


}
