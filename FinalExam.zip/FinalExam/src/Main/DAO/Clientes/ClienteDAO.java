package Main.DAO.Clientes;

import Main.DAO.Cheques.Cheques;
import Main.Modules.CRUD_DB;
import Main.ConexionDB.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
// REQ: PATRONES DE DISEÑO

public class ClienteDAO {

    public static List<Cliente> getAllClientes() throws SQLException {
        String query = "SELECT * FROM cliente";
        List<Cliente> ListaClientes = new ArrayList<>();

        try {
            CRUD_DB.setConnection(Conexion.getConexion());
            ResultSet rs = CRUD_DB.queryDB(query);

            while (rs.next()) {
                Cliente clientes = new Cliente(
                        rs.getString("identificacion"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("direccion"),
                        rs.getString("telefono"),
                        rs.getString("correo"),
                        rs.getString("estado"),
                        rs.getString("fecha_registro"),
                        rs.getString("ultima_actividad")
                        );
                ListaClientes.add(clientes);
            }
            rs.close();
        } catch (SQLException e) {
            System.out.println("Error al obtener los clientes: " + e.getMessage());
            CRUD_DB.rollbackDB();
            throw e;
        } finally {
            CRUD_DB.closeConnection();
        }

        return ListaClientes;
    }
}