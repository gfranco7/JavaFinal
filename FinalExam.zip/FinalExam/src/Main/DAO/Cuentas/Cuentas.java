package Main.DAO.Cuentas;

import java.util.ArrayList;

public class Cuentas {
    private int id_cuenta;
    private int id_cliente;

    private String tipo;
    private double saldo;
    private double limite_saldo;
    private String fecha_apertura;
    private String estado;

    private ArrayList <Cuentas> ListaCuentas;

    public Cuentas() {
    }

    public int getId_cuenta() {
        return id_cuenta;
    }

    public void setId_cuenta(int id_cuenta) {
        this.id_cuenta = id_cuenta;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public double getLimite_saldo() {
        return limite_saldo;
    }

    public void setLimite_saldo(double limite_saldo) {
        this.limite_saldo = limite_saldo;
    }

    public String getFecha_apertura() {
        return fecha_apertura;
    }

    public void setFecha_apertura(String fecha_apertura) {
        this.fecha_apertura = fecha_apertura;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public ArrayList<Cuentas> getListaCuentas() {
        return ListaCuentas;
    }

    public void setListaCuentas(ArrayList<Cuentas> listaCuentas) {
        ListaCuentas = listaCuentas;
    }

    @Override
    public String toString() {
        return "Cuentas{" + "id_cuenta = " + id_cuenta + ", id_cliente = " + id_cliente +", tipo = "+tipo +
                ", saldo = "+saldo +", limite_saldo = "+limite_saldo+ ", fecha_apertura = "+fecha_apertura +
                ", estado = "+estado +", listaCuentas = "+ListaCuentas+"}";
    }



}
