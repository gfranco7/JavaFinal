package Main.DAO.Cuentas;

//REQ: PATRONES DE DISEÑO

public class CuentasDAO {
}
