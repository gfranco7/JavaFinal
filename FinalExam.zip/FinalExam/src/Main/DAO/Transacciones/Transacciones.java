package Main.DAO.Transacciones;

import java.util.ArrayList;

public class Transacciones {
    private int id;
    private int id_cuenta;
    private String tipo;
    private double monto;
    private String fecha;
    private String referencia;
    private double saldo_anterior;
    private double saldo_nueva;
    private String estado;
    private ArrayList <Transacciones> listaTransacciones;


    public Transacciones() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_cuenta() {
        return id_cuenta;
    }

    public void setId_cuenta(int id_cuenta) {
        this.id_cuenta = id_cuenta;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public double getSaldo_anterior() {
        return saldo_anterior;
    }

    public void setSaldo_anterior(double saldo_anterior) {
        this.saldo_anterior = saldo_anterior;
    }

    public double getSaldo_nueva() {
        return saldo_nueva;
    }

    public void setSaldo_nueva(double saldo_nueva) {
        this.saldo_nueva = saldo_nueva;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public ArrayList<Transacciones> getListaTransacciones() {
        return listaTransacciones;
    }

    public void setListaTransacciones(ArrayList<Transacciones> listaTransacciones) {
        this.listaTransacciones = listaTransacciones;
    }

    @Override
    public String toString() {
        return "Transacciones{" + "id_transaccion = " + id + ", id_cuenta = " + id_cuenta +", tipo = "+tipo +
                ", monto = "+monto +", fecha = "+fecha+ ", referencia = "+referencia +
                ", saldo anterior = "+saldo_anterior +", saldo_nuevo = "+saldo_nueva+ ", estado = "+estado+"}";
    }

}
