package Main.DAO.Transacciones;

//REQ: PATRONES DE DISEÑO
public class TransaccionesDAO {
}
