package Main.Modules;

import Main.DAO.Cheques.Cheques;
import Main.DAO.Cheques.ChequesDAO;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Menus {
    private static final Scanner scanner = new Scanner(System.in);

    public static void mostrarMenu() {

        Scanner scanner = new Scanner(System.in);
        int opcion;

        while (true) {
            try {
                System.out.println("MENU BANCO UNICION");
                System.out.println("1. Registrar Cheque");
                System.out.println("2. Actualizar cheque");
                System.out.println("3. Listar reportes de chques");
                System.out.println("4. Encontrar cheque");
                System.out.println("5.Registrar reporte");
                System.out.println("0. Exit");
                System.out.print("Select an option: ");

                opcion = scanner.nextInt();
                scanner.nextLine();

                switch (opcion) {
                    case 1:
                        registrarCheque();
                        break;
                    case 2:
                        ActualizarCheque();
                        break;
                    case 3:
                        listarCheques();
                        break;
                    case 4:
                        buscarCheques();
                        break;
                    case 0:
                        System.out.println("Saliendo");
                        return;
                    default:
                        System.out.println("error.");
                }
            } catch (Exception e) {
                System.out.println("eror");
                scanner.nextLine();
            }
        }
    }

    public static void registrarCheque() {
        System.out.println("\n---- Registrar cheque ----");
        System.out.print("Numero de Cheque: ");
        String numero_cheque = scanner.nextLine();
        System.out.print("ID cuenta: ");
        int id_cuenta = scanner.nextInt();
        System.out.print("Beneficiario");
        String beneficiario = scanner.nextLine();
        System.out.print("Monto");
        int monto = scanner.nextInt();
        System.out.print("Monto en letras");
        String monto_letras = scanner.nextLine();
        System.out.print("Prioridad");
        String prioridad = scanner.nextLine();
        System.out.print("Firma digital");
        String firma_digital = scanner.nextLine();
        System.out.println("estado");
        String estado = scanner.nextLine();
        System.out.println("Razon rechazo");
        String razon_rechazo = scanner.nextLine();
        System.out.println("Fecha emision");
        String fecha_emision = scanner.nextLine();
        System.out.println("Fecha proceso");
        String fecha_proceso = scanner.nextLine();
        System.out.println("Cobrado");
        int cobrado = scanner.nextInt();
        System.out.println("Cuenta saldo momento");
        int cuenta_saldo_momento = scanner.nextInt();
        System.out.println("Fecha de modificacion");
        String fecha_modificacion = scanner.nextLine();
        System.out.println("Usuario modificacion");
        String usuario_mpodificacion = scanner.nextLine();


        Cheques cheque = new Cheques(numero_cheque,id_cuenta, beneficiario, monto, monto_letras, prioridad, firma_digital,
                estado, razon_rechazo, fecha_emision, fecha_proceso, cobrado, cuenta_saldo_momento, fecha_modificacion, usuario_mpodificacion);

        boolean result = ChequesDAO.insertCheque(cheque.getNumero_cheque(), cheque.getId_cuenta(),
                cheque.getBeneficiario(), cheque.getMonto(), cheque.getMonto_letras(), cheque.getPrioridad(),
                cheque.getFirma_digital(), cheque.getEstado(), cheque.getRazon_rechazo(), cheque.getFecha_emision(), cheque.getFehca_proceso(),
                cheque.getCobrado(), cheque.getCuenta_saldo_momento(), cheque.getFecha_modificacion(), cheque.getUsuario_modificacion());
        if (result) {
            System.out.println("Cheque registrado exitosamente.");
        } else {
            System.out.println("Error al registrar.");
        }
    }

    public static void ActualizarCheque() {
        try {
            System.out.print("Ingrese el ID del Cheque  ");
            int idCheque = scanner.nextInt();
            Cheques vet = ChequesDAO.getChequesById(idCheque);
            if (vet != null) {
                System.out.println("\nSeleccione el atributo a actualizar:");
                System.out.println("1. Monto");
                System.out.println("2. Fecha modificacion");
                System.out.println("2. Estado");
                System.out.println("0.  Salir ");
                System.out.print("Opción: ");
                int option = scanner.nextInt();
                scanner.nextLine();

                switch (option) {
                    case 1:
                        System.out.print("Nuevo monto: ");
                        double newmonto = scanner.nextDouble();
                        vet.setMonto(newmonto);
                        break;
                    case 2:
                        System.out.print("Fecha modificacion: ");
                        String fecha = scanner.nextLine();
                        vet.setFecha_modificacion(fecha);
                        break;
                    case 3:
                        System.out.print("Nuevo Estado: ");
                        String estado = scanner.nextLine();
                        vet.setEstado(estado);
                        break;

                    case 0:

                        return;
                    default:
                        System.out.println("Opción no válida.");
                        return;
                }

                boolean result = ChequesDAO.updateCheque(vet);
                if (result) {
                    System.out.println(" actualizado exitosamente.");
                } else {
                    System.out.println("Error al actualizar ");
                }
            } else {
                System.out.println("Cheque no encontrado.");
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar: " + e.getMessage());
        }
    }




    public static void listarCheques() {
        try {
            List<Cheques> ChequesListado = ChequesDAO.getAllCheques();
            if (ChequesListado.isEmpty()) {
                System.out.println("No hay cheques .");
            } else {
                for (Cheques cheque : ChequesListado) {
                    System.out.println(cheque);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al listar cheques: " + e.getMessage());
        }
    }




    public static void buscarCheques() {
        try {
            System.out.print("Ingrese el id del cheque: ");
            int id = scanner.nextInt();
            scanner.nextLine();
            Cheques cheque = ChequesDAO.getChequesById(id);
            if (cheque != null) {
                System.out.println(cheque);
            } else {
                System.out.println("Chque no encontrado.");
            }
        } catch (SQLException e) {
            System.out.println("Error al buscar  por ID: " + e.getMessage());
        }
    }



















}

